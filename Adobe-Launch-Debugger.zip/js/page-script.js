//console logging for server calls is planned here.


/*
This script is added by the Adobe Launch Debugger++ Chrome Extension.
*/
//window.postMessage({ from: 'web_accessible_resources.js', data: window["hoge"] })


//window.localStorage.setItem("adobeLaunchDebugger", JSON.stringify(statusCheck()));
//console.log("Adobe Launch Debugger: Finished parsing!");

